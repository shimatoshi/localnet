// sql.js ラッパー — SQLiteデータセットの検索・ページ取得

let SQL = null;
const openDBs = new Map();
const MAX_OPEN = 3;
let _searchIndexDb = null;

async function initSQL() {
  if (SQL) return SQL;
  SQL = await initSqlJs({
    locateFile: file => `https://sql.js.org/dist/${file}`
  });
  return SQL;
}

async function openDataset(name) {
  if (openDBs.has(name)) return openDBs.get(name);

  // LRU制限
  if (openDBs.size >= MAX_OPEN) {
    const oldest = openDBs.keys().next().value;
    openDBs.get(oldest).close();
    openDBs.delete(oldest);
  }

  const sql = await initSQL();
  const buffer = await dbStore.load(name);
  if (!buffer) return null;

  const db = new sql.Database(new Uint8Array(buffer));
  openDBs.set(name, db);
  return db;
}

function closeAllDatasets() {
  for (const [name, db] of openDBs) {
    db.close();
  }
  openDBs.clear();
}

async function openSearchIndex() {
  if (_searchIndexDb) return _searchIndexDb;
  const sql = await initSQL();
  const buffer = await dbStore.loadSearchIndex();
  if (!buffer) return null;
  _searchIndexDb = new sql.Database(new Uint8Array(buffer));
  return _searchIndexDb;
}

function closeSearchIndex() {
  if (_searchIndexDb) {
    _searchIndexDb.close();
    _searchIndexDb = null;
  }
}

async function searchAll(query, limit = 50) {
  const db = await openSearchIndex();
  if (!db) {
    // 検索インデックスがなければ従来方式にフォールバック
    return _searchAllLegacy(query, limit);
  }

  const results = [];
  try {
    const stmt = db.prepare(`
      SELECT p.id, p.url, p.title, p.domain, p.dataset,
             snippet(pages_fts, 1, '<b>', '</b>', '...', 32) as snippet,
             rank
      FROM pages_fts
      JOIN pages p ON p.id = pages_fts.rowid
      WHERE pages_fts MATCH ?
      ORDER BY rank
      LIMIT ?
    `);
    stmt.bind([query, limit]);
    while (stmt.step()) {
      results.push(stmt.getAsObject());
    }
    stmt.free();
  } catch (e) {
    // FTS5エラーならLIKEフォールバック
    console.warn('Search index FTS error, falling back to LIKE:', e.message);
    try {
      const stmt = db.prepare(`
        SELECT id, url, title, domain, dataset,
               substr(content_text, 1, 200) as snippet,
               0 as rank
        FROM pages
        WHERE content_text LIKE '%' || ? || '%' OR title LIKE '%' || ? || '%'
        LIMIT ?
      `);
      stmt.bind([query, query, limit]);
      while (stmt.step()) {
        results.push(stmt.getAsObject());
      }
      stmt.free();
    } catch (e2) {
      console.error('Search index LIKE error:', e2.message);
    }
  }

  return results;
}

async function _searchAllLegacy(query, limit = 50) {
  const datasets = await dbStore.listMeta();
  if (datasets.length === 0) return [];

  await initSQL();
  const results = [];

  for (const ds of datasets) {
    let db;
    try {
      db = await openDataset(ds.name);
      if (!db) continue;
    } catch (e) { continue; }

    try {
      const stmt = db.prepare(`
        SELECT p.id, p.url, p.title, p.domain,
               snippet(pages_fts, 1, '<b>', '</b>', '...', 32) as snippet,
               rank
        FROM pages_fts
        JOIN pages p ON p.id = pages_fts.rowid
        WHERE pages_fts MATCH ?
        ORDER BY rank
        LIMIT ?
      `);
      stmt.bind([query, limit]);
      while (stmt.step()) {
        const row = stmt.getAsObject();
        row.dataset = ds.name;
        results.push(row);
      }
      stmt.free();
    } catch (e) {
      try {
        const stmt = db.prepare(`
          SELECT id, url, title, domain,
                 substr(content_text, 1, 200) as snippet,
                 0 as rank
          FROM pages
          WHERE content_text LIKE '%' || ? || '%' OR title LIKE '%' || ? || '%'
          LIMIT ?
        `);
        stmt.bind([query, query, limit]);
        while (stmt.step()) {
          const row = stmt.getAsObject();
          row.dataset = ds.name;
          results.push(row);
        }
        stmt.free();
      } catch (e2) {}
    }
  }

  results.sort((a, b) => a.rank - b.rank);
  return results.slice(0, limit);
}

async function getPage(datasetName, pageId) {
  const db = await openDataset(datasetName);
  if (!db) return null;

  let stmt;
  try {
    stmt = db.prepare('SELECT content_html, mime, title, url FROM pages WHERE id = ?');
    stmt.bind([pageId]);
    if (!stmt.step()) return null;

    const row = stmt.getAsObject();
    const mime = row.mime;
    const title = row.title;
    const url = row.url;
    stmt.free();
    stmt = null;

    // BLOBを別クエリで取得
    let rawStmt;
    try {
      rawStmt = db.prepare('SELECT content_html FROM pages WHERE id = ?');
      rawStmt.bind([pageId]);
      rawStmt.step();
      const compressed = rawStmt.getAsObject(null)['content_html'];
      rawStmt.free();
      rawStmt = null;

      let html;
      if (compressed instanceof Uint8Array) {
        try {
          const blob = new Blob([compressed]);
          const ds = new DecompressionStream('gzip');
          const decompressed = blob.stream().pipeThrough(ds);
          html = await new Response(decompressed).text();
        } catch (e) {
          html = new TextDecoder().decode(compressed);
        }
      } else {
        html = String(compressed || '');
      }

      return { html, mime, title, url };
    } finally {
      if (rawStmt) rawStmt.free();
    }
  } finally {
    if (stmt) stmt.free();
  }
}

// URL正規化バリエーション生成
function urlVariations(url) {
  const vars = [url];
  // .html 有無
  if (url.endsWith('.html')) {
    vars.push(url.slice(0, -5)); // remove .html
  } else {
    vars.push(url + '.html');
  }
  // /index.html
  if (url.endsWith('/')) {
    vars.push(url + 'index.html');
  } else if (!url.endsWith('.html')) {
    vars.push(url + '/index.html');
  }
  // エンコード/デコード
  try {
    const decoded = decodeURIComponent(url);
    if (decoded !== url) {
      vars.push(decoded);
      if (!decoded.endsWith('.html')) vars.push(decoded + '.html');
    }
    const encoded = url.replace(/[^\x00-\x7F]/g, c => encodeURIComponent(c));
    if (encoded !== url) {
      vars.push(encoded);
      if (!encoded.endsWith('.html')) vars.push(encoded + '.html');
    }
  } catch (e) {}
  // 末尾スラッシュ有無
  if (url.endsWith('/')) {
    vars.push(url.slice(0, -1));
    vars.push(url.slice(0, -1) + '.html');
  }
  return [...new Set(vars)];
}

// ページURLから検索（リンクインターセプト用）
async function findPageByUrl(url) {
  await initSQL();
  const variations = urlVariations(url);

  // まず検索インデックスで対象データセットを特定
  const indexDb = await openSearchIndex();
  if (indexDb) {
    for (const v of variations) {
      let stmt;
      try {
        stmt = indexDb.prepare('SELECT dataset FROM pages WHERE url = ? LIMIT 1');
        stmt.bind([v]);
        if (stmt.step()) {
          const datasetName = stmt.getAsObject().dataset;
          stmt.free();
          stmt = null;
          // 対象データセットから実際のpage IDを取得
          const db = await openDataset(datasetName);
          if (db) {
            for (const v2 of variations) {
              let s;
              try {
                s = db.prepare('SELECT id FROM pages WHERE url = ? LIMIT 1');
                s.bind([v2]);
                if (s.step()) {
                  const row = s.getAsObject();
                  return { dataset: datasetName, id: row.id };
                }
              } finally {
                if (s) s.free();
              }
            }
          }
        }
      } catch (e) {
        continue;
      } finally {
        if (stmt) stmt.free();
      }
    }
  }

  // フォールバック: 全データセットを順に検索
  const datasets = await dbStore.listMeta();
  for (const ds of datasets) {
    const db = await openDataset(ds.name);
    if (!db) continue;

    for (const v of variations) {
      let stmt;
      try {
        stmt = db.prepare('SELECT id FROM pages WHERE url = ? LIMIT 1');
        stmt.bind([v]);
        if (stmt.step()) {
          const row = stmt.getAsObject();
          return { dataset: ds.name, id: row.id };
        }
      } catch (e) {
        continue;
      } finally {
        if (stmt) stmt.free();
      }
    }
  }
  return null;
}
