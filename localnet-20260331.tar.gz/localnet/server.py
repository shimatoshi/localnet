"""localnet — ローカルインターネット Flask API"""

import os
import re
import json
import time
import queue
import tarfile
import tempfile
from flask import Flask, request, jsonify, send_from_directory, Response, send_file

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)

from config import PORT, CACHE_BASE, DATASETS_DIR
from jobs import (
    get_job, stop_job, start_crawl_job, start_resume_job, start_build_job,
    start_import_job, get_all_sites, get_all_datasets,
)

app = Flask(__name__, static_folder='static')
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0


@app.after_request
def add_cors(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
    return response


# === 静的ファイル ===

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')


@app.route('/static/<path:path>')
def static_files(path):
    return send_from_directory('static', path)


# === データセット API ===

@app.route('/api/datasets')
def api_datasets():
    return jsonify(get_all_datasets())


@app.route('/api/datasets/<name>/download')
def api_dataset_download(name):
    os.makedirs(DATASETS_DIR, exist_ok=True)
    filename = f"{name}.sqlite" if not name.endswith('.sqlite') else name
    filepath = os.path.realpath(os.path.join(DATASETS_DIR, filename))
    if not filepath.startswith(os.path.realpath(DATASETS_DIR) + os.sep):
        return jsonify({"error": "不正なパスです"}), 400
    if os.path.exists(filepath):
        return send_from_directory(
            DATASETS_DIR, filename,
            as_attachment=True,
            mimetype='application/x-sqlite3',
        )
    return jsonify({"error": "データセットが見つかりません"}), 404


@app.route('/api/search-index/download')
def api_search_index_download():
    os.makedirs(DATASETS_DIR, exist_ok=True)
    filepath = os.path.join(DATASETS_DIR, 'search_index.sqlite')
    if os.path.exists(filepath):
        return send_from_directory(
            DATASETS_DIR, 'search_index.sqlite',
            as_attachment=True,
            mimetype='application/x-sqlite3',
        )
    return jsonify({"error": "検索インデックスがまだ構築されていません"}), 404


# === エクスポート/インポート API ===

@app.route('/api/export/<domain>')
def api_export(domain):
    if not re.match(r'^[a-zA-Z0-9._-]+$', domain):
        return jsonify({"error": "不正なドメイン名です"}), 400
    cache_dir = os.path.join(CACHE_BASE, domain)
    if not os.path.isdir(cache_dir):
        return jsonify({"error": "キャッシュが見つかりません"}), 404

    tmp = tempfile.NamedTemporaryFile(suffix='.tar.gz', delete=False)
    try:
        with tarfile.open(tmp.name, 'w:gz') as tar:
            tar.add(cache_dir, arcname=domain)
        return send_file(
            tmp.name,
            as_attachment=True,
            download_name=f"{domain}.tar.gz",
            mimetype='application/gzip',
        )
    except Exception as e:
        os.unlink(tmp.name)
        return jsonify({"error": str(e)}), 500


@app.route('/api/import', methods=['POST'])
def api_import():
    if 'file' not in request.files:
        return jsonify({"error": "ファイルが指定されていません"}), 400
    f = request.files['file']
    if not f.filename:
        return jsonify({"error": "ファイル名がありません"}), 400

    # 一時ファイルに保存
    tmp = tempfile.NamedTemporaryFile(suffix='.tar.gz', delete=False)
    try:
        f.save(tmp.name)
        # tar.gz内のトップレベルディレクトリ名をドメインとして使う
        with tarfile.open(tmp.name, 'r:*') as tar:
            members = tar.getnames()
            if not members:
                os.unlink(tmp.name)
                return jsonify({"error": "空のアーカイブです"}), 400
            # パストラバーサル防止
            for m in members:
                if m.startswith('/') or '..' in m:
                    os.unlink(tmp.name)
                    return jsonify({"error": "不正なパスがアーカイブに含まれています"}), 400
            domain = members[0].split('/')[0]
            if not re.match(r'^[a-zA-Z0-9._-]+$', domain):
                os.unlink(tmp.name)
                return jsonify({"error": f"不正なドメイン名: {domain}"}), 400
            tar.extractall(path=CACHE_BASE)

        os.unlink(tmp.name)
        # バックグラウンドでビルド
        job = start_import_job(domain)
        return jsonify(job.to_dict())
    except tarfile.TarError as e:
        os.unlink(tmp.name)
        return jsonify({"error": f"アーカイブ解凍エラー: {e}"}), 400
    except Exception as e:
        if os.path.exists(tmp.name):
            os.unlink(tmp.name)
        return jsonify({"error": str(e)}), 500


# === クロール API ===

@app.route('/api/crawl', methods=['POST'])
def api_crawl():
    data = request.get_json(force=True)
    url = data.get('url', '').strip()
    if not url:
        return jsonify({"error": "URLを指定してください"}), 400

    depth = int(data.get('depth', 0))  # 0 = 無制限
    if depth < 0:
        depth = 0
    delay = max(0.5, min(float(data.get('delay', 1.0)), 30.0))
    exclude = data.get('exclude', [])
    if isinstance(exclude, str):
        exclude = [p.strip() for p in exclude.split(',') if p.strip()]
    auto_build = bool(data.get('auto_build', True))

    job = start_crawl_job(url, depth, delay, exclude, auto_build)
    return jsonify(job.to_dict())


@app.route('/api/resume/<domain>', methods=['POST'])
def api_resume(domain):
    if not re.match(r'^[a-zA-Z0-9._-]+$', domain):
        return jsonify({"error": "不正なドメイン名です"}), 400
    job = start_resume_job(domain)
    return jsonify(job.to_dict())


@app.route('/api/build/<domain>', methods=['POST'])
def api_build(domain):
    if not re.match(r'^[a-zA-Z0-9._-]+$', domain):
        return jsonify({"error": "不正なドメイン名です"}), 400
    job = start_build_job(domain)
    return jsonify(job.to_dict())


@app.route('/api/jobs/<job_id>/stop', methods=['POST'])
def api_stop(job_id):
    if stop_job(job_id):
        return jsonify({"ok": True})
    return jsonify({"error": "ジョブが見つからないか停止できません"}), 404


@app.route('/api/jobs/active')
def api_active_jobs():
    from jobs import _jobs, _jobs_lock
    with _jobs_lock:
        active = [j.to_dict() for j in _jobs.values() if j.status == 'running']
    return jsonify(active)


@app.route('/api/sites')
def api_sites():
    return jsonify(get_all_sites())


# === ジョブ API ===

@app.route('/api/jobs/<job_id>/stream')
def api_stream(job_id):
    job = get_job(job_id)
    if not job:
        return jsonify({"error": "ジョブが見つかりません"}), 404

    def generate():
        max_duration = 86400  # 24時間（長時間クロール対応）
        start_time = time.time()
        while time.time() - start_time < max_duration:
            try:
                msg = job.log_queue.get(timeout=30)
                yield f"data: {json.dumps(msg, ensure_ascii=False)}\n\n"
                if msg.get('type') in ('done', 'error'):
                    break
            except queue.Empty:
                yield f"data: {json.dumps({'type': 'ping'})}\n\n"
                if job.status in ('done', 'error'):
                    break
        else:
            yield f"data: {json.dumps({'type': 'error', 'message': 'タイムアウト（24時間）'})}\n\n"

    return Response(
        generate(),
        mimetype='text/event-stream',
        headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'},
    )


@app.route('/api/jobs/<job_id>')
def api_job_status(job_id):
    job = get_job(job_id)
    if not job:
        return jsonify({"error": "ジョブが見つかりません"}), 404
    return jsonify(job.to_dict())


if __name__ == '__main__':
    os.makedirs(DATASETS_DIR, exist_ok=True)
    print(f'localnet starting on port {PORT}')
    print(f'ディレクトリ: {BASE_DIR}')
    app.run(host='0.0.0.0', port=PORT, debug=False, threaded=True)
